﻿using System;
class TechShop
{
    static void Main(string[] args)
    {
        DisplayWelcome();

        // Get number of products (1-5) with while loop validation       
        int numProducts = 0;
        while (numProducts < 1 || numProducts > 5)
        {
            Console.Write("How many products do you want to buy? (1-5): ");
            if (!int.TryParse(Console.ReadLine(), out numProducts) || numProducts < 1 || numProducts > 5)
            {
                Console.WriteLine("Invalid input. Please enter a number between 1 and 5.");
                numProducts = 0;
            }

        }
        // Separate variables for up to 5 products (no arrays as required)        
        string name1 = "", name2 = "", name3 = "", name4 = "", name5 = "";
        double price1 = 0, price2 = 0, price3 = 0, price4 = 0, price5 = 0;

        // For loop to collect each product       
        for (int i = 1; i <= numProducts; i++)
        {
            Console.Write($"\nEnter name for product {i}: ");
            string productName = Console.ReadLine();
            double productPrice = 0;
            while (productPrice <= 0)
            {
                Console.Write($"Enter price for product {i} (R): ");
                if (!double.TryParse(Console.ReadLine(), out productPrice) || productPrice <= 0)
                {
                    Console.WriteLine("Invalid price. Please enter a positive value.");
                    productPrice = 0;
                }
            }
            // Store in separate variables          
            if (i == 1) { name1 = productName; price1 = productPrice; }
            else if (i == 2) { name2 = productName; price2 = productPrice; }
            else if (i == 3) { name3 = productName; price3 = productPrice; }
            else if (i == 4) { name4 = productName; price4 = productPrice; }
            else if (i == 5) { name5 = productName; price5 = productPrice; }
        }

        // Calculate total using method        
        double total = CalculateTotal(price1, price2, price3, price4, price5);

        // Apply discount using if statement        
        double discount = 0;
        if (total >= 500)
        {
            discount = total * 0.05;
        }
        double discountedTotal = total - discount;

        // Calculate tax using method       
        double tax = CalculateTax(discountedTotal);
        double finalAmount = discountedTotal + tax;

        // Display order summary using method        
        DisplayOrderSummary(
        numProducts,
        name1, price1,
        name2, price2,
        name3, price3,
        name4, price4,
        name5, price5,
        total, discount, tax, finalAmount
        );
    }
    static void DisplayWelcome()
    {
        Console.WriteLine("========================================");
        Console.WriteLine(" Welcome to TechShop Checkout! ");
        Console.WriteLine("========================================\n");
    }
    static double CalculateTotal(double p1, double p2, double p3, double p4, double p5)
    {
        return p1 + p2 + p3 + p4 + p5;
    }
    static double CalculateTax(double amount)
    {
        return amount * 0.10;
    }
    static void DisplayOrderSummary(
  int count,
  string n1, double p1,
  string n2, double p2,
  string n3, double p3,
  string n4, double p4,
  string n5, double p5,
  double total, double discount, double tax, double finalAmount)
    {
        Console.WriteLine("\n========================================");
        Console.WriteLine(" ORDER SUMMARY ");
        Console.WriteLine("========================================");
        if (count >= 1) Console.WriteLine($" {n1,-20} R{p1:F2}");
        if (count >= 2) Console.WriteLine($" {n2,-20} R{p2:F2}");
        if (count >= 3) Console.WriteLine($" {n3,-20} R{p3:F2}");
        if (count >= 4) Console.WriteLine($" {n4,-20} R{p4:F2}");
        if (count >= 5) Console.WriteLine($" {n5,-20} R{p5:F2}");

        Console.WriteLine("----------------------------------------");
        Console.WriteLine($" Total Purchase: R{total:F2}");
        Console.WriteLine($" Discount Applied: R{discount:F2}");
        Console.WriteLine($" Tax (10%): R{tax:F2}");
        Console.WriteLine("========================================");
        Console.WriteLine($" Final Amount to Pay: R{finalAmount:F2}");
        Console.WriteLine("========================================");
    }
}
